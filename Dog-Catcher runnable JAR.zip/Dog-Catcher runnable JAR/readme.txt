1. Run Dog-Catcher.jar with Terminal or CMD. (Script to run in Terminal provided in run-me.sh)

2. Input desired number of cats (triangles) and dogs (circle) separated by space.

3. Controls:

‘e’ – expand the size of the net (the center location of the net shouldn’t change).‘c’ – contract (decrease) the size of the net (the center location shouldn’t change).‘s’ – scoop up all the animals that are in the net.[right] – move the net to the right.[left] – move the net to the left.[up] – move the net up.[down] – move the net down.‘q’ – quit

Additional Notes:

Sounds folder must be in the same directory as Dog-Catcher.jar