cd ./
java -jar Dog-Catcher.jar